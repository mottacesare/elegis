--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: product; Type: TABLE; Schema: public; Owner: ovas; Tablespace: 
--

CREATE TABLE product (
    id integer NOT NULL,
    name character varying NOT NULL,
    type smallint DEFAULT 0
);


ALTER TABLE public.product OWNER TO ovas;

--
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: ovas
--

CREATE SEQUENCE product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_id_seq OWNER TO ovas;

--
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ovas
--

ALTER SEQUENCE product_id_seq OWNED BY product.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ovas
--

ALTER TABLE ONLY product ALTER COLUMN id SET DEFAULT nextval('product_id_seq'::regclass);


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: ovas
--

COPY product (id, name, type) FROM stdin;
1	Birra	0
2	Vino	0
3	Panino	1
4	Patatine	1
\.


--
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ovas
--

SELECT pg_catalog.setval('product_id_seq', 4, true);


--
-- Name: product_pkey; Type: CONSTRAINT; Schema: public; Owner: ovas; Tablespace: 
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

